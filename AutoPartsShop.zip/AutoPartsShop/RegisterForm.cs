﻿using System;
using System.Data.OleDb;
using System.Windows.Forms;

namespace AutoPartsShop
{
    public partial class RegisterForm : Form
    {
        private DatabaseHelper dbHelper; // Добавляем экземпляр DatabaseHelper

        public RegisterForm()
        {
            InitializeComponent();
            dbHelper = new DatabaseHelper(); // Инициализируем помощник БД
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            string login = txtLogin.Text;
            string password = txtPassword.Text;
            string name = txtName.Text;

            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password) || string.IsNullOrEmpty(name))
            {
                MessageBox.Show("Все поля должны быть заполнены", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (var conn = dbHelper.GetConnection()) // Используем экземпляр dbHelper
                {
                    conn.Open();

                    // Проверка на существование логина
                    string checkQuery = "SELECT COUNT(*) FROM Users WHERE Login = @login";
                    OleDbCommand checkCmd = new OleDbCommand(checkQuery, conn);
                    checkCmd.Parameters.AddWithValue("@login", login);
                    int userCount = (int)checkCmd.ExecuteScalar();

                    if (userCount > 0)
                    {
                        MessageBox.Show("Пользователь с таким логином уже существует", "Ошибка",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    // Регистрация нового пользователя
                    string insertQuery = "INSERT INTO Users (Login, [Password], UserName, IsAdmin) VALUES (@login, @password, @username, False)";
                    OleDbCommand insertCmd = new OleDbCommand(insertQuery, conn);
                    insertCmd.Parameters.AddWithValue("@login", login);
                    insertCmd.Parameters.AddWithValue("@password", password);
                    insertCmd.Parameters.AddWithValue("@name", name);

                    int rowsAffected = insertCmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Регистрация успешна!", "Успех",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);

                        this.Hide();
                        LoginForm loginForm = new LoginForm();
                        loginForm.Show();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при регистрации: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void RegisterForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                LoginForm loginForm = new LoginForm();
                loginForm.Show();
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            LoginForm loginForm = new LoginForm();
            loginForm.Show();
        }

        private void RegisterForm_Load(object sender, EventArgs e)
        {

        }
    }
}